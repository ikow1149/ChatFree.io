from django.db import models

# Create your models here.
class Chat(models.Model):
    textfrom = models.CharField(max_length=20)
    chat = models.CharField(max_length=750)

   
    def __str__(self):
        return self.textfrom
   
    