from django.shortcuts import render
import socket
from .models import Chat

def home(request):
    return render(request,'index.html')

def connection(request):
    Ip_get = socket.gethostname()
    IP = socket.gethostbyname(Ip_get)
    data = {'myname':IP}
    return render(request,'connecting.html',data)
def chat(request):
    Ip_get = socket.gethostname()
    IP = socket.gethostbyname(Ip_get)
    try:
        message = request.POST.get('typechat')
        if message == None:
            pass
        elif message == '':
            pass
        else:
            new_msg = Chat(textfrom = IP,chat=message)
            new_msg.save()
            
    except:
        message =f"(Computer generated message) {IP} is online"
    chats = []
    for item in Chat.objects.all():
        chat = item.textfrom+":-"+item.chat
        chats.append(chat)
    if chats == []:
        chats.append('(Computer generated message) All data has been flushed. You can chat newly now.')
        # new_msg = Chat(textfrom = IP,chat=)
        # new_msg.save()
    data = {'chats':chats}
    
    return render(request,'chat.html',data)
# Create your views here.
